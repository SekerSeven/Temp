public class W07Practical {
    public static void main(String[] args) throws Exception {
        Tests tests = new Tests();
        tests.scenario1();
        tests.scenario2();
        tests.scenario3();
        tests.scenario4();
        tests.scenario5();
    }
}
